//
//  Created by Van Thanh on 15/5/25.
//
import Foundation

protocol ___VARIABLE_moduleName___InteractorProtocol {}

class ___VARIABLE_moduleName___Interactor: ___VARIABLE_moduleName___InteractorProtocol {}
