//
//  Created by Van Thanh on 15/5/25.
//

import Foundation

class ___VARIABLE_moduleName___ViewModel: ViewModelType {
    
    private var interactor: ___VARIABLE_moduleName___InteractorProtocol
    private var navigator: ___VARIABLE_moduleName___NavigatorProtocol
    private var input: Input!
    private var output: Output!
    
    
    init(navigator: ___VARIABLE_moduleName___NavigatorProtocol,
         interactor: ___VARIABLE_moduleName___InteractorProtocol) {
        self.navigator = navigator
        self.interactor = interactor
    }
    
    struct Input {}
    
    struct Output {}
    
    func transform(input: Input) -> Output {
        self.input = input
        self.output = Output()
        return output
    }
    
}
