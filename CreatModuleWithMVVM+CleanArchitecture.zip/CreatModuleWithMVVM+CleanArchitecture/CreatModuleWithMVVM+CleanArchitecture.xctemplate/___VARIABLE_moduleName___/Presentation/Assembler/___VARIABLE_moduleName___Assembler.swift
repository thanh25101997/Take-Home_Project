//
//  Created by Van Thanh 2025.
//

import Foundation

protocol ___VARIABLE_moduleName___Assembler where Self: DefaultAssembler {
    func createModule() -> ___VARIABLE_moduleName___ViewController
}

extension ___VARIABLE_moduleName___Assembler where Self: DefaultAssembler {
    
    func createModule() -> ___VARIABLE_moduleName___ViewController {
        let vc = ___VARIABLE_moduleName___ViewController()
        let vm = ___VARIABLE_moduleName___ViewModel(navigator: ___VARIABLE_moduleName___Navigator(vc: vc),
                                      interactor: ___VARIABLE_moduleName___Interactor())
        vc.viewModel = vm
        return vc
    }
    
}
